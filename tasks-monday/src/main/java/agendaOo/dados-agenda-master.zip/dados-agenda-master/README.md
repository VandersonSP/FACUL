## Você deve ter no mínimo o JDK 8 instalado.

Primeiramente altere o arquivo: `ArquivoUtil.java` na linha: 7

Mudando o diretório base, para  o caminho completo do arquivo no seu computador (Desde o `C:`).

Dentro do diretório `dados-agenda/src/main/java`

Rode o comando: `javac -cp . br/com/fam/*.java` isso irá compilar todos arquivos.

Após rode o comando: `java -cp . br/com/fam/Main` no mesmo diretório e o programa será iniciado.
